import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  alumnes: any[] = [];
  selectedAlumne: any = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadAlumnes();
  }

  loadAlumnes(): void {
    this.http.get<any[]>('assets/llistat-alumnes.json').subscribe({
      next: (data) => {
        console.log('Dades carregades correctament:', data); // Mostra les dades carregades
        this.alumnes = data;
      },
      error: (err) => {
        console.error('Error carregant dades:', err); // Mostra qualsevol error
      }
    });
  }
  

  selectAlumne(alumne: any): void {
    this.selectedAlumne = alumne;
  }

  deselectAlumne(): void {
    this.selectedAlumne = null;
  }

  objectKeys(obj: any): string[] {
    return Object.keys(obj);
  }
}
