import { Routes } from '@angular/router';
import { LlistatComponent } from './llistat/llistat.component';
import { CalendariComponent } from './calendari/calendari.component';
import { HomeComponent } from './home/home.component';
import { NotesComponent } from './notes/notes.component';

export const routes: Routes = [
  { path: 'home', component: HomeComponent }, // Ruta explícita per 'home'
  { path: 'llistat', component: LlistatComponent },
  { path: 'calendari', component: CalendariComponent },
  { path: 'notes', component: NotesComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' }, // Redirigeix la ruta buida a 'home'
  { path: '**', redirectTo: 'home' } // Redirigeix rutes desconegudes a 'home'
];
