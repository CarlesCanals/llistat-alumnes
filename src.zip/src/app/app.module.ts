import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LlistatComponent } from './llistat/llistat.component';
import { CalendariComponent } from './calendari/calendari.component';
import { NotesComponent } from './notes/notes.component';

const routes: Routes = [
  { path: 'llistat', component: LlistatComponent },
  { path: 'calendari', component: CalendariComponent },
  { path: 'notes', component: NotesComponent },
  { path: '', redirectTo: '/llistat', pathMatch: 'full' },
  { path: '**', redirectTo: '/llistat' }
];

@NgModule({
  declarations: [
    AppComponent,
    LlistatComponent,
    CalendariComponent,
    NotesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule, // Afegeix HttpClientModule
    RouterModule.forRoot(routes)
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
